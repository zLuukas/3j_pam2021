import { DashboardComponent } from './components/dashboard/dashboard.component';
import { CalendarioComponent } from './components/calendario/calendario.component';
import { LoginComponent } from './components/login/login.component';
import { MateriaisComponent } from './components/materiais/materiais.component';
import { CursosComponent } from './components/cursos/cursos.component';
import { FotosComponent } from './components/fotos/fotos.component';
import { NoticiasComponent } from './components/noticias/noticias.component';
import { HomeComponent } from './components/home/home.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'noticias', component: NoticiasComponent },
  { path: 'fotos', component: FotosComponent },
  { path: 'cursos', component: CursosComponent },
  { path: 'materiais', component: MateriaisComponent },
  { path: 'login', component: LoginComponent },
  { path: 'calendario', component: CalendarioComponent },
  { path: 'login/dash', component: DashboardComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
