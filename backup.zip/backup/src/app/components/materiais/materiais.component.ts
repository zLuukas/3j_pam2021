import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-materiais',
  templateUrl: './materiais.component.html',
  styleUrls: ['./materiais.component.css']
})
export class MateriaisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
